import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
})
export class AdminComponent implements OnInit {
  customers: any[] = [];
  newCustomer = {
    name: '',
    contactNumber: '',
    address: {
      houseNumber: '',
      streetName: '',
      city: '',
      state: '',
      pincode: '',
    },
  };

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadCustomers();
  }

  loadCustomers(): void {
    this.apiService.getAllCustomers().subscribe((data) => {
      this.customers = data;
    });
  }

  addCustomer(): void {
    this.apiService.addCustomer(this.newCustomer).subscribe(() => {
      alert('Customer added successfully!');
      this.loadCustomers();
    });
  }
}